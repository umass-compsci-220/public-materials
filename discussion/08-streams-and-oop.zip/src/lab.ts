import { snode, Stream, sempty } from "../include/stream.js";
import { Observable } from "../include/observable.js";

type Tree<T> = { left?: Tree<T>; v: T; right?: Tree<T> };

// TODO: Exercise 1
export function preorderStream<T>(t: Tree<T> | undefined): Stream<T> {
  return sempty<T>(); // default return value
}

// TODO: Exercise 2
export function merge(o1: Observable<string>, o2: Observable<string>): Observable<string> {
  return new Observable(); // default return value
}
