import { concatIt, prependIt } from "./lab.js";

interface MyIterator<T> {
  hasNext: () => boolean;
  next: () => T;
}

function createIteratorFromArray<T>(arr: T[]): MyIterator<T> {
  let i = 0;
  return {
    hasNext: () => i < arr.length,
    next: () => arr[i++],
  };
}

describe("concatIt", () => {
  it("generates correct sequence for two number iterators", () => {
    const iter1: MyIterator<number> = createIteratorFromArray([1, 2, 3]);
    const iter2: MyIterator<number> = createIteratorFromArray([4, 5, 6]);
    const result = concatIt(iter1, iter2);
    const expected = [1, 2, 3, 4, 5, 6];
    let i = 0;
    while (result.hasNext()) {
      expect(result.next()).toEqual(expected[i++]);
    }
    expect(i).toEqual(expected.length);
  });

  it("generates correct sequence for two string iterators", () => {
    const iter1: MyIterator<string> = createIteratorFromArray(["cs", "220", "spring", "2025"]);
    const iter2: MyIterator<string> = createIteratorFromArray(["lab", "4"]);
    const result = concatIt(iter1, iter2);
    const expected = ["cs", "220", "spring", "2025", "lab", "4"];
    let i = 0;
    while (result.hasNext()) {
      expect(result.next()).toEqual(expected[i++]);
    }
    expect(i).toEqual(expected.length);
  });

  it("generates correct sequence for empty iter1", () => {
    const iter1: MyIterator<number> = createIteratorFromArray([]);
    const iter2: MyIterator<number> = createIteratorFromArray([10, 20, 30]);
    const result = concatIt(iter1, iter2);
    const expected = [10, 20, 30];
    let i = 0;
    while (result.hasNext()) {
      expect(result.next()).toEqual(expected[i++]);
    }
    expect(i).toEqual(expected.length);
  });

  it("generates correct sequence for empty iter2", () => {
    const iter1: MyIterator<number> = createIteratorFromArray([5, 15, 25]);
    const iter2: MyIterator<number> = createIteratorFromArray([]);
    const result = concatIt(iter1, iter2);
    const expected = [5, 15, 25];
    let i = 0;
    while (result.hasNext()) {
      expect(result.next()).toEqual(expected[i++]);
    }
    expect(i).toEqual(expected.length);
  });

  it("generates correct sequence for 2 empty iterators", () => {
    const iter1: MyIterator<number> = createIteratorFromArray([]);
    const iter2: MyIterator<number> = createIteratorFromArray([]);
    const result = concatIt(iter1, iter2);
    expect(result.hasNext()).toBe(false);
  });
});

describe("prependIt", () => {
  it("correctly prepends to a number iterator", () => {
    const iter: MyIterator<number> = createIteratorFromArray([1, 2, 3]);
    const p = 0;
    const result = prependIt(p, iter);
    const expected = [0, 1, 2, 3];
    let i = 0;
    while (result.hasNext()) {
      expect(result.next()).toEqual(expected[i++]);
    }
    expect(i).toEqual(expected.length);
  });

  it("correctly prepends to a string iterator", () => {
    const iter: MyIterator<string> = createIteratorFromArray(["220", "spring", "2025"]);
    const p = "cs";
    const result = prependIt(p, iter);
    const expected = ["cs", "220", "spring", "2025"];
    let i = 0;
    while (result.hasNext()) {
      expect(result.next()).toEqual(expected[i++]);
    }
    expect(i).toEqual(expected.length);
  });

  it("correctly prepends to an empty iterator", () => {
    const iter = createIteratorFromArray([]);
    const p = 1;
    const result = prependIt(p, iter);
    const expected = [1];
    let i = 0;
    while (result.hasNext()) {
      expect(result.next()).toEqual(expected[i++]);
    }
    expect(i).toEqual(expected.length);
  });

  it("correctly prepends multple times", () => {
    const iter: MyIterator<number> = createIteratorFromArray([40, 50, 60]);
    const result = prependIt(10, prependIt(20, prependIt(30, iter)));
    const expected = [10, 20, 30, 40, 50, 60];
    let i = 0;
    while (result.hasNext()) {
      expect(result.next()).toEqual(expected[i++]);
    }
    expect(i).toEqual(expected.length);
  });
});
