import { preorderStream, merge } from "./lab.js";
import { Observable } from "../include/observable.js";
import { snode, sempty, Stream } from "../include/stream.js";
import assert from "assert";

type Tree<T> = { left?: Tree<T>; v: T; right?: Tree<T> };

function printStream<T>(s: Stream<T>): void {
  if (s.isEmpty()) return;
  console.log(s.head());
  printStream(s.tail());
}

function streamToArray<T>(s: Stream<T>): T[] {
  const arr: T[] = [];
  while (!s.isEmpty()) {
    arr.push(s.head());
    s = s.tail();
  }
  return arr;
}

describe("preorderStream", () => {
  it("tests with empty tree", () => {
    const t = undefined;
    const stream = preorderStream(t);
    const output = streamToArray(stream);
    const expected: number[] = [];
    expect(output).toEqual(expected);
  });

  it("tests with tree with 1 element", () => {
    const t: Tree<number> = { v: 10 };
    const stream = preorderStream(t);
    const output = streamToArray(stream);
    const expected = [10];
    expect(output).toEqual(expected);
  });

  it("tests with tree having only left child nodes", () => {
    // const t: Tree<number> = {left: {left: {left: {v: 20}, v: 15}, v: 10}, v: 5}
    const t: Tree<number> = { v: 5, left: { v: 10, left: { v: 15, left: { v: 20, left: { v: 25 } } } } };
    const stream = preorderStream(t);
    const output = streamToArray(stream);
    const expected = [5, 10, 15, 20, 25];
    expect(output).toEqual(expected);
  });

  it("tests with tree having only right child nodes", () => {
    // const t: Tree<number> = {left: {left: {left: {v: 20}, v: 15}, v: 10}, v: 5}
    const t: Tree<number> = { v: 3, right: { v: 6, right: { v: 9, right: { v: 12, right: { v: 15 } } } } };
    const stream = preorderStream(t);
    const output = streamToArray(stream);
    const expected = [3, 6, 9, 12, 15];
    expect(output).toEqual(expected);
  });

  it("tests with mixed tree", () => {
    const t = {
      left: { left: { v: 3 }, v: 2, right: { v: 4 } },
      v: 1,
      right: { v: 5, right: { left: { v: 7 }, v: 6, right: { v: 8 } } },
    };
    const stream = preorderStream(t);
    const output = streamToArray(stream);
    const expected = [1, 2, 3, 4, 5, 6, 7, 8];
    expect(output).toEqual(expected);
  });
});

describe("merge", () => {
  it("correctly merges two observables into a single observable", () => {
    const o1: Observable<string> = new Observable();
    const o2: Observable<string> = new Observable();
    const solution = merge(o1, o2);
    const input = [
      { obs: 2, v: "-100" },
      { obs: 1, v: "-50" },
      { obs: 1, v: "-51" },
      { obs: 2, v: "-50" },
      { obs: 2, v: "0" },
      { obs: 1, v: "0" },
      { obs: 2, v: "12" },
      { obs: 1, v: "11" },
      { obs: 2, v: "5" },
      { obs: 2, v: "15" },
      { obs: 2, v: "16" },
      { obs: 1, v: "19.5" },
      { obs: 1, v: "19" },
      { obs: 2, v: "20" },
      { obs: 1, v: "30" },
      { obs: 1, v: "-20" },
      { obs: 2, v: "50" },
      { obs: 2, v: "49.9" },
    ];
    let count = 20;

    // @ts-ignore
    solution.subscribe(x => x === input.shift()!.v);

    while (input.length !== 0) {
      [o1, o2][input[0].obs - 1].update(input[0].v);
      count--;
      assert(count > 0);
    }
  });
});
