import { Statement, BinaryOperator, Expression } from "../include/parser.js";

/**
 * Exercise 1
 * Scoping
 */
export function printDecls(program: Statement[], level: number) {
  function doDecl(s: Statement, scope: { [key: string]: any }) {
    switch (s.kind) {
      // TODO: Complete this switch statement
      default:
        return;
    }
  }

  const scope = {};
  // TODO: Use the doDecl helper by iterating through the program
}

/**
 * Exercise 2
 * Async & Interpreters
 */
type State = { [key: string]: boolean };
type AsyncExpression =
  | { kind: "boolean"; value: boolean }
  | { kind: "variable"; name: string }
  | { kind: "operator"; operator: "&&" | "||"; left: AsyncExpression; right: AsyncExpression };

export function interpExpressionAsync(s: State, e: AsyncExpression): Promise<boolean> {
  switch (e.kind) {
    case "boolean":
      return Promise.resolve(true); // Replace these
    case "variable":
      return Promise.resolve(true); // Replace these
    case "operator":
      return Promise.resolve(true); // Replace these
  }
}

/**
 * Bonus Exercise
 * Type Inference
 */
type Type = string;
interface TypeMap {
  [key: string]: Type;
}
interface BinExp {
  operator: BinaryOperator;
  left: Expression;
  right: Expression;
}
const boolOp = (s: string) => s === "&&" || s === "||";
const cmpOp = (s: string) => s === "<" || s === ">";
const mathOp = (s: string) => s === "+" || s === "-" || s === "*" || s === "/";

const checkEq = (v: any, oldT: Type, newT: Type) => {
  if (newT !== "any" && oldT !== newT) {
    throw new Error(`type mismatch for ${v}: is ${oldT}, should be ${newT}`);
  }
};

export function typeCheck(e: Expression, expected: Type, env: TypeMap): Type {
  function checkBoth(e: BinExp, operandType: Type, resultType: Type) {
    typeCheck(e.left, operandType, env);
    typeCheck(e.right, operandType, env);
    checkEq(e.operator, resultType, expected);
    return resultType;
  }

  switch (e.kind) {
    // TODO: Complete this switch statement
    default:
      return expected;
  }
}
