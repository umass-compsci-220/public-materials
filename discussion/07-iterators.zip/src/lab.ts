// In Class Exercises

/**
 * EXERCISE 1
 *
 * Implement the function makeRepeat that returns an instance of a custom RepeatIterator class.
 * The RepeatIterator class should be an iterable iterator that produces the given value N times.
 * N is assumed to be a non-negative integer.
 */

class RepeatIterator<T> implements IterableIterator<T> {
  // TODO: Implement this class
}

export function makeRepeat<T>(value: T, count: number) {
  // TODO: Implement this function
  return new RepeatIterator(); // replace as needed
}

// Try using the iterator produced by makeRepeat below!
// Run the code below after uncommenting it using npm run start

// for (const item of makeRepeat("spam", 3)) {
//     console.log(item);
// }

// for (const item of makeRepeat("spam", 1)) {
//     console.log(item);
// }

// for (const item of makeRepeat("egg", 0)) {
//     console.log(item);
// }

/**
 * EXERCISE 2
 *
 * Write a function that takes in an array of iterables and returns an instance of a custom
 * ChainIterator class. The ChainIterator class should be an iterable iterator that yields
 * items from the first iterable until it runs out. It should then yield items from the next
 * iterable in the given array, repeating this process until reaching the end of the array of
 * iterables.
 *
 * You may assume the given array is not empty.
 *
 */

class ChainIterator<T> implements IterableIterator<T> {
  // TODO: Implement this class
}

export function makeChain<T>(iterables: Iterable<T>[]): ChainIterator<T> {
  // TODO: Implement this function
  return new ChainIterator(); // replace as needed
}
