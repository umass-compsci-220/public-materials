import { Observable } from "../include/observable.js";
import { snode, Stream, sempty } from "../include/stream.js";

// Should be "observable"
export class Economy extends Observable<number> {
  updateRate(rate: number): void {
    // Notify whoever cares about the economy
    // TODO: Implement this method
  }
}

// Should observe Economy's rate, and be "observable"
export class Stock extends Observable<number> {
  constructor(name: string, base: number, price: number) {
    super();
    // TODO: Implement the constructor
  }

  updatePrice(rate: number): void {
    // Use formula `price = base * rate` to update price
    // TODO: Implement this method
  }
}

//  Make changes to Newscast for Exercise 2 only!
//  Should observe and report Stock's price
export class Newscast extends Observable<[string, number]> {
  constructor() {
    super();
  }

  report(name: string, price: number): void {
    console.log(`Stock ${name} has price ${price}.`);
    // TODO: Update subscribers with tuple [name, price]
  }

  observe(stocks: Stock[]): void {
    // TODO: Implement this method
  }
}

const USEconomy = new Economy();
const stock = new Stock("GME", 5.0, 1.0);
const news = new Newscast();

USEconomy.subscribe(rate => stock.updatePrice(rate));
stock.subscribe(price => news.report("GME", price));

USEconomy.updateRate(5); // “Stock GME has price 5.”
USEconomy.updateRate(1); // “Stock GME has price 1.”

// Exercise 3
export function maxUpTo(s: Stream<number>): Stream<number> {
  // TODO: Implement this method
  return s;
}
