import { Statement, BinaryOperator, Expression } from "../include/parser.js";

/**
 * Exercise 1
 * Scoping
 */
export function printDecls(program: Statement[], level: number) {
  function doDecl(s: Statement, scope: { [key: string]: any }) {
    switch (s.kind) {
      // TODO: Complete this switch statement
      default:
        return;
    }
  }

  const scope = {};
  // TODO: Use the doDecl helper by iterating through the program
}

/**
 * Exercise 2
 * Type Inference
 */
type Type = string;
interface TypeMap {
  [key: string]: Type;
}
interface BinExp {
  operator: BinaryOperator;
  left: Expression;
  right: Expression;
}
const boolOp = (s: string) => s === "&&" || s === "||";
const cmpOp = (s: string) => s === "<" || s === ">";
const mathOp = (s: string) => s === "+" || s === "-" || s === "*" || s === "/";

const checkEq = (v: any, oldT: Type, newT: Type) => {
  if (newT !== "any" && oldT !== newT) {
    throw new Error(`type mismatch for ${v}: is ${oldT}, should be ${newT}`);
  }
};

export function typeCheck(e: Expression, expected: Type, env: TypeMap): Type {
  function checkBoth(e: BinExp, operandType: Type, resultType: Type) {
    typeCheck(e.left, operandType, env);
    typeCheck(e.right, operandType, env);
    checkEq(e.operator, resultType, expected);
    return resultType;
  }

  switch (e.kind) {
    // TODO: Complete this switch statement
    default:
      return expected;
  }
}
