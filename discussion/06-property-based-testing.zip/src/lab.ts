import assert from "assert";

export function oracle(genArray: (num: number) => number[][]) {
  // TODO: Implement this function
}
