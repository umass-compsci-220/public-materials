import * as fetch_import from "cross-fetch";

export let fetchImplementation = fetch_import.fetch;

export function resetImplementation() {
    fetchImplementation = fetch_import.fetch;
}

export function setImplementation(impl) {
    fetchImplementation = impl;
}

function fetch(url) {
    return fetchImplementation(url);
}

export default fetch;