import { getObjsWithName, composeFunctionsAsync } from "./lab.js";
import { setImplementation, resetImplementation } from "../include/fetch.js";
import { jest } from "@jest/globals";

const SECOND = 1000;
jest.setTimeout(30 * SECOND);

beforeEach(() => resetImplementation());

describe("getObjsWithName", () => {
  it("works if all promises fulfill with an array of ObjsWithName", async () => {
    const objs = {
      a: [{ name: "test1a" }, { name: "test1b" }],
      b: [{ name: "test2a" }, { name: "test2b" }],
      c: [{ name: "test3a" }, { name: "test3b" }],
    };

    setImplementation(url => {
      const obj = JSON.stringify(objs[url]);
      return Promise.resolve(new Response(obj));
    });

    const urls = ["a", "b", "c"];
    const res = await getObjsWithName(urls);

    const should_include = {
      test1a: 1,
      test1b: 1,
      test2a: 1,
      test2b: 1,
      test3a: 1,
      test3b: 1,
    };

    res.forEach(o => {
      expect(--should_include[o.name]).toBe(0);
    });
  });

  it("returns empty array if all promises reject", async () => {
    setImplementation(() => {
      return Promise.reject();
    });

    const urls = ["a", "b", "c"];
    const res = await getObjsWithName(urls);

    expect(res).toHaveLength(0);
  });

  it("returns empty array if all promises fulfill but object have no name field", async () => {
    const objs = {
      a: [{}, {}],
      b: [{}, {}],
      c: [{}, {}],
    };

    setImplementation(url => {
      const obj = JSON.stringify(objs[url]);
      return Promise.resolve(new Response(obj));
    });

    const urls = ["a", "b", "c"];
    const res = await getObjsWithName(urls);

    expect(res).toHaveLength(0);
  });

  it("works with a mix of fulfilled and rejected promises and if fulfilled, name field is not always present", async () => {
    const objs = {
      a: [{ name: "test1a" }, { name: "test1b" }],
      b: [{ name: "test2a" }, {}],
      c: [{}, {}],
    };

    setImplementation(url => {
      if (url === "d") {
        return Promise.reject();
      }
      const obj = JSON.stringify(objs[url]);
      return Promise.resolve(new Response(obj));
    });

    const urls = ["a", "b", "c"];
    const res = await getObjsWithName(urls);

    const should_include = {
      test1a: 1,
      test1b: 1,
      test2a: 1,
    };

    res.forEach(o => {
      expect(--should_include[o.name]).toBe(0);
    });
  });
});

describe("composeFunctionsAsync", () => {
  it("composes async functions correctly", async () => {
    const myFunction = composeFunctionsAsync([
      (x) => x >= 0 ? Promise.resolve(Math.sqrt(x)) : Promise.reject(new Error("Must be >= 0")),
      (x) => Math.abs(x) < 1 ? Promise.resolve(Math.acos(x)) : Promise.reject(new Error("Must have absolute value less than 1"))
    ]);

    const call1 = myFunction(-4);
    await expect(call1).rejects.toEqual(new Error("Must be >= 0"));

    const call2 = myFunction(4);
    await expect(call2).rejects.toEqual(new Error("Must have absolute value less than 1"));

    const call3 = myFunction(0.5);
    await expect(call3).resolves.toBeCloseTo(Math.acos(Math.sqrt(0.5)));
  });
});
