import { atLeastHalf, countBlue, countBlue2D } from "./lab.js";
import fs from "fs";

type Color = [number, number, number];

describe("countBlue", () => {
  it("works correctly", () => {
    const input: Color[] = [
      [1, 1, 50],
      [1, 50, 50],
      [50, 1, 50],
      [40, 40, 81],
    ];
    const expected_output = 2;
    const output = countBlue(input);
    expect(output).toEqual(expected_output);
  });
});

describe("countBlue2D", () => {
  it("works correctly", () => {
    const input: Color[][] = [
      [
        [1, 1, 50],
        [1, 50, 50],
        [50, 1, 50],
        [40, 40, 81],
      ],
      [
        [3, 40, 50],
        [1, 50, 50],
        [50, 1, 50],
        [40, 40, 81],
      ],
    ];
    const expected_output = 3;
    const output = countBlue2D(input);
    expect(output).toEqual(expected_output);
  });
});

describe("atLeastHalf", () => {
  it("works correctly with numbers", () => {
    const input = [93, 54, 46, 4, 60];

    const func = (x: number) => x % 4 == 1;
    expect(atLeastHalf(input, func)).toStrictEqual(false);

    const func2 = (x: number) => x % 3 == 0;
    expect(atLeastHalf(input, func2)).toStrictEqual(true);
  });

  it("works correctly with strings", () => {
    const input = ["apple", "banana", "strawberry"];

    const func = (x: string) => x.length > 6;
    expect(atLeastHalf(input, func)).toStrictEqual(false);

    const func2 = (x: string) => x.length % 2 == 0;
    expect(atLeastHalf(input, func2)).toStrictEqual(true);
  });
});
