import assert from "assert";

/**
 *  Exercise 1: Property Based Testing
 */

function randomPositiveInteger() {
  return Math.floor(Math.random() * 1000 + 1);
}

export function oracle(genArray: (num: number) => number[][]) {
  // TODO: Implement this function
}

//////// Observers //////////

export type Coordinate = { x: number; y: number };

export interface MouseObserver {
  readonly screen: number;

  // update observer with new mouse click coordinate
  update_coordinate(coord: Coordinate): void;

  // update observer with new mouse drag event
  update_drag(start: Coordinate, end: Coordinate): void;
}

export interface MouseSubject {
  // adds an Observer to the set of subscribers
  subscribe(subscriber: MouseObserver): void;

  // removes an Observer from the set of subscribers
  unsubscribe(subscriber: MouseObserver): void;
}

// Exercise 2

export class MouseEvents implements MouseSubject {
  constructor(num_screens: number) {
    // TODO: Implement this constructor
  }

  subscribe(subscriber: MouseObserver): void {
    // TODO: Implement this method
  }

  unsubscribe(subscriber: MouseObserver): void {
    // TODO: Implement this method
  }

  mouse_click(screen: number, coord: Coordinate): void {
    // TODO: Implement this method
  }

  mouse_drag(screen: number, start: Coordinate, end: Coordinate): void {
    // TODO: Implement this method
  }
}
