import assert from "assert";
import fetchMock from "jest-fetch-mock";
import { getObjsWithName } from "./lab.js";
import { jest } from "@jest/globals";

const SECOND = 1000;
jest.setTimeout(30 * SECOND);

// Exercise 1: write tests for getObjsWithName
describe("getObjsWithName", () => {
  beforeEach(() => {
    fetchMock.enableMocks();
  });

  afterEach(() => {
    fetchMock.resetMocks();
    fetchMock.disableMocks();
  });

  // TODO: write your tests here
});
