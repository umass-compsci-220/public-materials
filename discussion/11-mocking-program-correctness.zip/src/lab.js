// The function that you will test

export function getObjsWithName(urls) {
  return Promise.allSettled(
    urls.map(url =>
      fetch(url)
        .then(res => (res.ok ? res.json() : Promise.reject(new Error(`Error: ${res.statusText}`)))) // Error would bubble though.
        .then(res => (Array.isArray(res) ? res : []))
    )
  ).then(resarr =>
    resarr
      .filter(res => res.status === "fulfilled")
      .map(res => res["value"])
      .map(objarr => objarr.filter(obj => "name" in obj))
      .flat()
  );
}

// Exercise 1: write tests for getObjsWithName

// 1. write your tests in lab.test.js
// 2. you can then run your tests on your solution above
// 3. or comment out your solution above and uncomment the flawed solutions below
//    one by one to see if your tests catch these mistakes
// (select the lines you want to comment or uncomment and press "ctrl" and "/", "cmd" and "/" if on macOS )

// Flawed solution 1:
// export function getObjsWithName(urls) {
//   return Promise.allSettled(
//     urls.map(url =>
//       fetch(url)
//         .then(res => res.json())
//     )
//   ).then(resarr =>
//     resarr
//       .filter(res => res.status === "fulfilled")
//       .map(res => res.value)
//       .map(objarr => objarr.filter(obj => "name" in obj))
//   );
// }

// Flawed solution 2:
// export function getObjsWithName(urls) {
//   return Promise.allSettled(
//     urls.map(url =>
//       fetch(url)
//         .then(out => out.json())
//     )
//   ).then(_ => []);
// }

// Flawed solution 3:
// export function getObjsWithName(urls) {
//   return Promise.all(
//     urls.map(url =>
//       fetch(url)
//         .then(res => res.json())
//     )
//   ).then(resarr =>
//     resarr
//       .map(objarr => objarr.filter(obj => "name" in obj))
//       .flat()
//   );
// }

// Exercise 2: Program Correctness

// Your answer here:
const A = null; // Change this value to your answer

// Exercise code starts here:
let n = 0;
let s = A;

while (s <= 100) {
  if (n % 2 > 0) {
    s += n;
  } else {
  }

  n = n + 1;
}
