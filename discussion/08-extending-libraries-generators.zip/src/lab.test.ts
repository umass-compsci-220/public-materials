import { CenteredPolygon, chainGenerator } from "./lab.js";
import assert from "assert";

function makeIterable<T>(vals: T[]): Iterable<T> {
  return {
    [Symbol.iterator]: () => {
      let idx = 0;
      return {
        next: () => {
          if (idx < vals.length) {
            return { done: false, value: vals[idx++] };
          }
          return { done: true, value: undefined };
        },
      };
    },
  };
}

describe("center", () => {
  it("returns the only point if the polygon has only one vertex", () => {
    const polygon = new CenteredPolygon([[10, 20]]);
    expect(polygon.center()).toEqual([10, 20]);
  });
  it("returns the correct center for a 2-vertex shape", () => {
    const polygon = new CenteredPolygon([
      [1, 2],
      [3, 4],
    ]);
    expect(polygon.center()).toEqual([2, 3]);
  });
  it("returns the correct center for a triangle", () => {
    const polygon = new CenteredPolygon([
      [1, 2],
      [3, 4],
      [5, 6],
    ]);
    expect(polygon.center()).toEqual([3, 4]);
  });
  it("returns the correct center for a many-sided shape", () => {
    const polygon = new CenteredPolygon([
      [0, 0],
      [1, 1],
      [2, 2],
      [10, -10],
      [-100, 100],
      [42, 315],
    ]);
    expect(polygon.center()).toEqual([-7.5, 68]);
  });
});

describe("chainGenerator", () => {
  it("returns the correct sequence for array of one iterable", () => {
    expect(Array.from(chainGenerator([[1, 2, 3]]))).toEqual([1, 2, 3]);
  });

  it("returns the correct sequence for array of more than one iterable", () => {
    expect(
      Array.from(
        chainGenerator([
          [1, 2, 3],
          [4, 5, 6],
          [7, 8, 9],
        ])
      )
    ).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9]);
  });

  it("returns the correct sequence for array with empty iterables at the start", () => {
    expect(Array.from(chainGenerator([[], ["a", "b", "c"]]))).toEqual(["a", "b", "c"]);
  });

  it("returns the correct sequence for array with empty iterables in the middle", () => {
    expect(Array.from(chainGenerator([["a", "b", "c"], [], ["d", "e"]]))).toEqual(["a", "b", "c", "d", "e"]);
  });

  it("returns the correct sequence for array with empty iterables at the end", () => {
    expect(Array.from(chainGenerator([["a", "b"], [], ["c", "d"], []]))).toEqual(["a", "b", "c", "d"]);
  });

  it("returns the correct sequence for array with all empty iterables", () => {
    expect(Array.from(chainGenerator([[], [], []]))).toEqual([]);
  });

  it("returns the correct sequence for array with non-array iterables", () => {
    const iterables = [[1, 2], [], [3, 4, 5], [6], []].map(makeIterable);
    expect(Array.from(chainGenerator(iterables))).toEqual([1, 2, 3, 4, 5, 6]);
  });

  it("generator terminates correctly", () => {
    const iterables = [[1, 2], [3]];
    const generator = chainGenerator(iterables);
    expect(Array.from(generator)).toEqual([1, 2, 3]);
    for (let i = 6; i > 0; i--) {
      expect(generator.next()).toEqual({ done: true, value: undefined });
    }
  });
});
