// Exercise 1: Mental Models (see slides and worksheet)

// Exercise 2: Closures
export function factorialSum(): () => number {
  // TODO: Implement this function
  return () => 0;
}
