// Exercise 1: Closures
export function mostTrue<T>(funarr: ((arg: T) => boolean)[]): (arg: T) => boolean {
  // TODO: Implement this function
  return (x: T) => true; // dummy, replace as needed
}

// Exercise 2: Iterators
interface MyIterator<T> {
  hasNext: () => boolean;
  next: () => T;
}

export function mkIterator(n: number): MyIterator<[number, number]> {
  // TODO: Implement this function
  return {
    hasNext: () => false,
    next: () => [0, 0],
  }; // dummy, replace as needed
}

// Exercise 3: More Closures
export function approxE(): () => number {
  // TODO: Implement this function
  return () => 0; // dummy, replace as needed
}
