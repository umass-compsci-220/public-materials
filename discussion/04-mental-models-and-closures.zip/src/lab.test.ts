import { rotateRight } from "./lab.js";

// your tests go here
