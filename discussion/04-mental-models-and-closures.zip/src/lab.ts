interface MyIterator<T> {
  hasNext: () => boolean;
  next: () => T;
}

// Exercise 1: Concatenate 2 iterators
export function concatIt<T>(it1: MyIterator<T>, it2: MyIterator<T>) {
  // TODO: complete this function
  return {
    hasNext: () => false,
    next: () => {},
  }; // dummy, replace as needed
}

// Exercise 2: Mental Models (no Gradescope)
const mkList = <T>(init: T, f: (x: T) => T) => ({
  next: () => mkList(f(init), f),
  value: () => init,
});
let cnt = 0;
const a = [mkList(0, x => x + 1), mkList(cnt, _ => ++cnt)];
const b = a.map(lst => lst.next().next());
console.log(b[1].value());

// Exercise 3: Prepend value to iterator
export function prependIt<T>(v: T, it2: MyIterator<T>): MyIterator<T> {
  // TODO: complete this function
  return {
    hasNext: () => false,
    next: () => v,
  }; // dummy, replace as needed
}
