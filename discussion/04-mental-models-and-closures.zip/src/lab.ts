// Execise 1: Mental Models
const mkList = <T>(init: T, f: (x: T) => T) => ({
  next: () => mkList(f(init), f),
  value: () => init,
});

let cnt = 0;
const a = [mkList(0, x => x + 1), mkList(cnt, () => ++cnt)];
const b = a.map(lst => lst.next().next());
console.log(b[1].value());

// Exercise 2: Closures
export function mostTrue<T>(funarr: ((arg: T) => boolean)[]): (arg: T) => boolean {
  // TODO: Implement this function
  return (x: T) => true;
}

// Exercise 3: Closures
export function approxE(): () => number {
  // TODO: Implement this function
  return () => 0;
}
