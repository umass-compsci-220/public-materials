// Exercise 1: Mental Models (see slides)

// Exercise 2: Testing with Jest
export function rotateRight<T>(arr: T[], k: number): T[] {
  const n = arr.length;
  if (n === 0) return [];

  k = k % n;

  if (k < 0) {
    throw new Error("k must be a non-negative integer");
  }

  if (k === 0) return arr.slice();

  return arr.slice(-k).concat(arr.slice(0, n - k));
}

// TODO: write tests for rotateRight in lab.test.ts
