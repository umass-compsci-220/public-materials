// Exercise 1: Closures
export function mostTrue<T>(funarr: ((arg: T) => boolean)[]): (arg: T) => boolean {
  // TODO: Implement this function
  return (x: T) => true;
}

// Exercise 2: Mental Models (see slides)

// Exercise 3: More Closures
export function approxE(): () => number {
  // TODO: Implement this function
  return () => 0;
}
