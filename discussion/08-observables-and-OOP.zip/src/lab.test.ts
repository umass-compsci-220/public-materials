import { maxUpTo, FluentFilter, factorialClosure, factorialStream } from "./lab.js";
import { snode, sempty, Stream } from "../include/stream.js";
import assert from "assert";

describe("FluentFilter", () => {
  const mockData = [{ a: -4 }, { a: -3 }, { b: -2 }, { b: -1 }, { a: 0 }, { a: 1 }, { b: 2 }, { b: 3 }, { a: 4 }];

  it("if the condition always returns false, data is empty in returned FluentFilter", () => {
    const ff = new FluentFilter<number>(mockData);
    const crit = [{ name: "a", f: (_g: number) => false }];
    const result = ff.filter(crit);
    expect(result.data).toEqual([]);
  });

  it("if the named field does not exist, data is empty in returned FluentFilter", () => {
    const ff = new FluentFilter<number>(mockData);
    const crit = [{ name: "z", f: (_g: number) => true }];
    const result = ff.filter(crit);
    expect(result.data).toEqual([]);
  });

  it("returns only evens if that is the condition", () => {
    const ff = new FluentFilter<number>(mockData);
    const crit = [{ name: "a", f: (g: number) => g % 2 === 0 }];
    const result = ff.filter(crit);
    expect(result.data).toEqual([{ a: -4 }, { a: 0 }, { a: 4 }]);
  });

  it("chaining filter calls works", () => {
    const ff = new FluentFilter<number>(mockData);
    const crit1 = [{ name: "a", f: (g: number) => g % 2 === 0 }];
    const crit2 = [{ name: "a", f: (g: number) => g >= 0 }];
    const result = ff.filter(crit1).filter(crit2);
    expect(result.data).toEqual([{ a: 0 }, { a: 4 }]);
  });

  it("two conditions works", () => {
    const ff = new FluentFilter<number>(mockData);
    const crit1 = [
      { name: "b", f: (g: number) => g % 2 === 0 },
      { name: "b", f: (g: number) => g >= 0 },
    ];
    const result = ff.filter(crit1);
    expect(result.data).toEqual([{ b: 2 }]);
  });
});

function arrayStreamComp(s: Stream<number>, arr: number[]): boolean {
  let temp_stream = s;
  const ret = true;
  for (let i = 0; i < arr.length; ++i) {
    assert(temp_stream.head() === arr[i]);
    temp_stream = temp_stream.tail();
  }
  return ret;
}

describe("maxUpTo", () => {
  it("Increasing stream remains the same", () => {
    const stream = snode(1, () => snode(3, () => snode(5, () => sempty())));
    const result = maxUpTo(stream);
    expect(result).not.toBe(stream);
    arrayStreamComp(result, [1, 3, 5]);
    expect(result.tail().tail().tail().isEmpty()).toBeTruthy();
  });

  it("Decreasing stream is the first number", () => {
    const stream = snode(5, () => snode(3, () => snode(1, () => sempty())));
    const result = maxUpTo(stream);
    expect(result).not.toBe(stream);
    arrayStreamComp(result, [5, 5, 5]);
    expect(result.tail().tail().tail().isEmpty()).toBeTruthy();
  });

  it("Random stream is correct", () => {
    const stream = snode(1, () => snode(0, () => snode(5, () => sempty())));
    const result = maxUpTo(stream);
    expect(result).not.toBe(stream);
    arrayStreamComp(result, [1, 1, 5]);
    expect(result.tail().tail().tail().isEmpty()).toBeTruthy();
  });
});

describe("Factorial functions", () => {
  it("factorialClosure returns closure that returns correct first 6", () => {
    const f = factorialClosure();
    const result = new Array(6).fill(1).map(f);
    expect(result).toEqual([1, 1, 2, 6, 24, 120]);
  });

  it("multiple factorialClosure closures do not clash", () => {
    const f1 = factorialClosure();
    const result1 = new Array(2).fill(0).map(f1);
    expect(result1).toEqual([1, 1]);
    const f2 = factorialClosure();
    const result2 = new Array(1).fill(0).map(f2);
    expect(result2).toEqual([1]);
  });

  it("first 6 nodes of the stream are correct", () => {
    arrayStreamComp(factorialStream(), [1, 1, 2, 6, 24, 120]);
    // Check if you can make two streams
    arrayStreamComp(factorialStream(), [1, 1, 2, 6, 24, 120]);
  });
});
