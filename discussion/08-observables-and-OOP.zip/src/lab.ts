import { snode, Stream, sempty } from "../include/stream.js";

export type Criterion<T> = { name: string; f: (g: T) => boolean };
export type Data = { [key: string]: any };

// Exercise 1
export class FluentFilter<T> {
  data: Data[];

  // TODO: implement the constructor
  constructor(data: Data[]) {
    this.data = [];
  }

  // TODO: Implement this method
  filter(crit: Criterion<T>[]): FluentFilter<T> {
    return this;
  }
}

// Exercise 2
export function maxUpTo(s: Stream<number>): Stream<number> {
  // TODO: Implement this method
  return s;
}

// Exercise 3
export function harmonicClosure(): () => number {
  // TODO: Implement this function
  return () => 0;
}

export function harmonicStream(): Stream<number> {
  // TODO: Implement this function
  return sempty();
}
