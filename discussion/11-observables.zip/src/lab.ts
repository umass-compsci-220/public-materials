export type Coordinate = { x: number; y: number };

export interface MouseObserver {
  readonly screen: number;

  // update observer with new mouse click coordinate
  update_coordinate(coord: Coordinate): void;

  // update observer with new mouse drag event
  update_drag(start: Coordinate, end: Coordinate): void;
}

export interface Observable {
  // adds an Observer to the set of subscribers
  subscribe(subscriber: MouseObserver): void;

  // removes an Observer from the set of subscribers
  unsubscribe(subscriber: MouseObserver): void;
}

// Exercise 1

export class MouseEvents implements Observable {
  constructor(num_screens: number) {
    // TODO: Implement this constructor
  }

  subscribe(subscriber: MouseObserver): void {
    // TODO: Implement this method
  }

  unsubscribe(subscriber: MouseObserver): void {
    // TODO: Implement this method
  }

  mouse_click(screen: number, coord: Coordinate): void {
    // TODO: Implement this method
  }

  mouse_drag(screen: number, start: Coordinate, end: Coordinate): void {
    // TODO: Implement this method
  }
}

// Exercise 2

// Should print out all coordinate and mouse drag updates for a specific screen
export class MouseEventLogger implements MouseObserver {
  readonly screen: number;

  constructor(screen: number) {
    this.screen = screen;
  }

  update_coordinate(coord: Coordinate): void {
    // TODO: Implement this method
  }

  update_drag(start: Coordinate, end: Coordinate): void {
    // TODO: Implement this method
  }
}

// Should print out area of bounding box around all mouse clicks, and area of bounding box for mouse drags
export class MouseEventArea implements MouseObserver {
  readonly screen: number;

  constructor(screen: number) {
    this.screen = screen;
    // TODO: Implement the rest of this constructor
  }

  update_coordinate(coord: Coordinate): void {
    // TODO: Implement this method
  }

  update_drag(start: Coordinate, end: Coordinate): void {
    // TODO: Implement this method
  }
}
