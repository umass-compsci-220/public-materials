import { List, node, empty } from "../include/lists.js";

// In Class Exercises

// Exercise 1: Lists
export function merge(l1: List<number>, l2: List<number>): List<number> {
  // TODO: complete this function
  return empty();
}

// Exercise 2: Closures

// Please complete the closures exercise on Gradescope!
