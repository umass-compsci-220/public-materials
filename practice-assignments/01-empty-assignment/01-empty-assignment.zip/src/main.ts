// To run me:
// 1. Open a VSCode terminal (Terminal -> New Terminal)
// 2. Type in "npm run start" (No quotes)
// 3. Press Enter
console.log("Hello, world!");
