import assert from "assert";
import { BusinessQuery, cycle, pairwise } from "./iterators-generators";
import { Business } from "../include/data";

describe("pairwise", () => {
  // Write tests for pairwise here
});

describe("cycle", () => {
  // Write tests for cycle here
});

describe("BusinessQuery.slice", () => {
  // Write tests for BusinessQuery.slice here
});

describe("BusinessQuery.filter", () => {
  // Write tests for BusinessQuery.filter here
});

describe("BusinessQuery.exclude", () => {
  // Write tests for BusinessQuery.exclude here
});
