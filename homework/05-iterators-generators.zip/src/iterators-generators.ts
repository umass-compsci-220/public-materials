import type { Business } from "../include/data";

export function* pairwise<T>(iterable: Iterable<T>): Generator<[T, T]> {
  throw new Error('Not implemented');
}

export function* cycle<T>(iterables: Iterable<T>[]): Generator<T> {
  throw new Error('Not implemented');
}

type FilterFunc = (business: Business) => boolean;

// Declare the BusinessQuery class here.
// Start the declaration with "export class" so that
// it can be imported from other modules.
export class BusinessQuery {}

export class SliceError extends Error {}
