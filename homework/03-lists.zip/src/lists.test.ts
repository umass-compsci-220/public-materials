import assert from "assert";
import { List, node, empty } from "../include/lists.js";
import {
  everyNList,
  everyNRev,
  everyNCond,
  nonNegativeProducts,
  negativeProducts,
  squashList,
  composeList,
  composeFunctions,
} from "./lists.js";

describe("everyNList", () => {
  // Tests for everyNList go here
});

describe("everyNRev", () => {
  // Tests for everyNRev go here
});

describe("everyNCond", () => {
  // Tests for everyNCond go here
});

describe("nonNegativeProducts", () => {
   // Tests for nonNegativeProducts go here
});

describe("negativeProducts", () => {
    // Tests for nonNegativeProducts go here
});

describe("squashList", () => {
  // Tests for squashList go here
});

describe("composeList", () => {
  // Tests for composeList go here
});
