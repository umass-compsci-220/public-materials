import type { Agent } from "./simulation_object/agent.js";
import type { Structure } from "./simulation_object/structure.js";
import type { View } from "./view.js";

export class Model {
  // Implement this method according to the singleton pattern seen in class
  static getInstance(): Model {
    throw new Error("Not implemented yet");
  }

  // Call next tick on every simulation object
  nextTick() {
  }

  // Add the given agent to the simulation and ask it to broadcast
  // its initial state.
  // The behavior is unspecified if an agent with the same ID already exists.
  addAgent(agent: Agent) {
  }

  // Return the agent with the specified id.
  // The behavior is unspecified if no agent with that id exists.
  getAgent(id: string): Agent {
    throw new Error("Not implemented yet");
  }

  // Add the given structure to the simulation and ask it to broadcast
  // its initial state.
  // The behavior is unspecified if a structure with the same ID already exists.
  addStructure(structure: Structure) {
  }

  // Subscribe the given view to recieve updates from the model
  attach(view: View) {
  }
}
