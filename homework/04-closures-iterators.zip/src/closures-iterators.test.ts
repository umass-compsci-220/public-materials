import assert from "assert";
import { List, node, empty, listToArray, arrayToList } from "../include/lists.js";
// listToArray and arrayToList are provided for your testing convenience only.
import {
  MyIterator, composeList, composeFunctions, composeBinary, enumRatios, cycleArr, dovetail
} from "./closures-iterators.js";

describe("composeList", () => {
  // Tests for composeList go here
});

describe("composeFunctions", () => {
  // Tests for composeFunctions go here
});

describe("composeBinary", () => {
  // Tests for composeBinary go here
});

describe("enumRatios", () => {
  // Tests for enumRatios go here
});

describe("cycleArr", () => {
  // Tests for cycleArr go here
});

describe("dovetail", () => {
  // Tests for dovetail go here
});