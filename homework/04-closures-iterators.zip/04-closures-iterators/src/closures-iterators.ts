import { List, node, empty } from "../include/lists.js";

export interface MyIterator<T> { hasNext: () => boolean; next: () => T }

export function composeList<T>(lst: List<(n: T) => T>): (n: T) => T {
  return _ => undefined as T; // dummy, replace
}

export function composeFunctions<T>(fns: ((x: T) => T)[]): (x: T) => T[] {
  return _ => []; // dummy, replace
}

export function composeBinary<T, U>(funArr: ((arg1: T, arg2: U) => T)[]): (a: U) => (x: T) => T {
  return _ => (_ => undefined as T); // dummy, replace
}

export function enumRatios(): () => number {
  return () => NaN; // dummy, replace
}

export function cycleArr<T>(arr: T[][]): MyIterator<T> {
  return { hasNext: () => false, next: () => { throw 0; } } // dummy, replace
}

export function dovetail<T>(lists: List<T>[]): MyIterator<T> {
  return { hasNext: () => false, next: () => { throw 0; } } // dummy, replace
}