type BinOp = "+" | "-" | "*" | "/" | "&&" | "||" | ">" | "<" | "===";
export type Expr =
  | { kind: "boolean"; value: boolean }
  | { kind: "number"; value: number }
  | { kind: "variable"; name: string }
  | { kind: "operator"; op: BinOp; e1: Expr; e2: Expr };

export type Stmt =
  | { kind: "let"; name: string; expression: Expr }
  | { kind: "assignment"; name: string; expression: Expr }
  | { kind: "if"; test: Expr; truePart: Stmt[]; falsePart: Stmt[] }
  | { kind: "while"; test: Expr; body: Stmt[] }
  | { kind: "print"; expression: Expr };

// export function parseExpression(str: string): Expr {}

// export function parseProgram(str: string): Stmt[] {}
