let x = 1;

while (x < 10) {
  x = x + 1;
}

print(x);
