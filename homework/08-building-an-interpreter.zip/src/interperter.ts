// import { Expression, Statement } from "../include/parser";

// interface Scope {
//   outer?: Scope;
//   declarations: Record<string, number | boolean>;
// }

// export function interpretExpression(exp: Expression);

// export function interpretProgram(program: Statement[]) {}
