import { Expression, Statement } from "../include/parser.js";

type RuntimeValue = number | boolean;
export type State = { [key: string]: State | RuntimeValue };

const PARENT_STATE_KEY = "[[PARENT]]";

export function interpExpression(state: State, exp: Expression): RuntimeValue {
  // TODO
  return false;
}

export function interpStatement(state: State, stmt: Statement): void {
  // TODO
  return;
}

export function interpProgram(program: Statement[]): State {
  // TODO
  return {};
}
