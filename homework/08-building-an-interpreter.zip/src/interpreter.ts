import { Expression, Statement } from "../include/parser.js";

type RuntimeValue = number | boolean;
const PARENT_STATE_KEY = Symbol("[[PARENT]]");
export type State = { [PARENT_STATE_KEY]?: State, [key: string]: RuntimeValue }

export function interpExpression(state: State, exp: Expression): RuntimeValue {
  // TODO
  return false;
}

export function interpStatement(state: State, stmt: Statement): void {
  // TODO
  return;
}

export function interpProgram(program: Statement[]): State {
  // TODO
  return {};
}
