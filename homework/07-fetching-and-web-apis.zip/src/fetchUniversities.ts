import fetch from "../include/fetch.js";

export function fetchUniversities(query: string): Promise<string[]> {
  // TODO
  return new Promise(res => res([]));
}
