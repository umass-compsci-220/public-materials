import fetch from "cross-fetch";

export default fetch;