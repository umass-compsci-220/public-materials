export type GenericFunction<T> = (x: T) => T;
