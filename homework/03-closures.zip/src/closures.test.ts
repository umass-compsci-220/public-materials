import assert from "assert";
import { composeFunctions, cyclic, rateLimiter, byParity, vendingMachine, wageChange, sineSeries } from "./closures";

describe("composeFunctions", () => {
  // Write tests for composeFunctions here
});

describe("cyclic", () => {
  // Write tests for cyclic here
});

describe("rateLimiter", () => {
  // Write tests for rateLimiter here
});

describe("byParity", () => {
  // Write tests for byParity here
});

describe("vendingMachine", () => {
  // Write tests for vendingMachine here
});

describe("wageChange", () => {
  // Write tests for wageChange here
});

describe("sineSeries", () => {
  // Write tests for sineSeries here
});
