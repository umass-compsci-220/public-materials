import { GenericFunction } from "../include/types.js";

export function composeFunctions<T>(funs: GenericFunction<T>[]): (x: T) => T[] {
  // TODO
  return (x: T) => []; // dummy, replace as needed
}

export function cyclic<T>(values: T[]): () => T {
  // TODO
  return () => undefined as T; // dummy, replace as needed
}

export function rateLimiter<T, R>(func: (x: T, y: T) => R, limit: number): (x: T, y: T) => R | undefined {
  // TODO
  return (x, y) => undefined;
}

export function byParity(evenFunc: (n: number) => number, oddFunc: (n: number) => number): (n: number) => number {
  // TODO
  return (n: number) => n; // dummy, replace as needed
}

export function vendingMachine(price: number, stock: number): (amount: number) => number | undefined {
  // TODO
  return (amount: number) => undefined; // dummy, replace as needed
}

export function wageChange(
  calcNew: (yr: number, prevWage: number) => number
): (startWage: number, startYr: number, endYr: number) => number {
  // TODO
  return (startWage: number, startYr: number, endYr: number) => 0; // dummy, replace as needed
}

export function sineSeries(x: number): (moreTerms?: number) => number {
  // TODO
  return moreTerms => 0; // dummy, replace as needed
}
