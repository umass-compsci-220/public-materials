import assert from "assert";
import { List, node, empty, listToArray, arrayToList } from "../include/lists.js";
// listToArray and arrayToList are provided for your testing convenience only.
import {
  insertOrdered,
  everyNRev,
  everyNCond,
  keepTrendMiddles,
  keepLocalMaxima,
  keepLocalMinima,
  keepLocalMinimaAndMaxima,
  nonNegativeProducts,
  negativeProducts,
  deleteFirst,
  deleteLast,
  squashList,
} from "./lists.js";

describe("insertOrdered", () => {
  // Tests for insertOrdered go here
});

describe("everyNRev", () => {
  // Tests for everyNRev go here
});

describe("everyNCond", () => {
  // Tests for everyNCond go here
});

describe("keepTrendMiddles", () => {
  // Tests for keepTrendMiddles go here
});

describe("keepLocalMaxima", () => {
  // Tests for keepLocalMaxima go here
});

describe("keepLocalMinima", () => {
  // Tests for keepLocalMinima go here
});

describe("keepLocalMinimaAndMaxima", () => {
  // Tests for keepLocalMinimaAndMaxima go here
});

describe("nonNegativeProducts", () => {
  // Tests for nonNegativeProducts go here
});

describe("negativeProducts", () => {
  // Tests for nonNegativeProducts go here
});

describe("deleteFirst", () => {
  // Tests for deleteFirst go here
});

describe("deleteLast", () => {
  // Tests for deleteLast go here
});

describe("squashList", () => {
  // Tests for squashList go here
});