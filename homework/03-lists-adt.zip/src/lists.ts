import { List, node, empty } from "../include/lists.js";

export function insertOrdered(lst: List<number>, el: number): List<number> {
  return lst; // dummy, replace as needed
}

export function everyNRev<T>(lst: List<T>, n: number): List<T> {
  return lst; // dummy, replace as needed
}

export function everyNCond<T>(lst: List<T>, n: number, cond: (e: T) => boolean): List<T> {
  return lst; // dummy, replace as needed
}

export function keepTrendMiddles(
  lst: List<number>,
  allSatisfy: (prev: number, curr: number, next: number) => boolean
): List<number> {
  return lst; // dummy, replace as needed
}

export function keepLocalMaxima(lst: List<number>): List<number> {
  return lst; // dummy, replace as needed
}

export function keepLocalMinima(lst: List<number>): List<number> {
  return lst; // dummy, replace as needed
}

export function keepLocalMinimaAndMaxima(lst: List<number>): List<number> {
  return lst; // dummy, replace as needed
}

export function nonNegativeProducts(lst: List<number>): List<number> {
  return lst; // dummy, replace as needed
}

export function negativeProducts(lst: List<number>): List<number> {
  return lst; // dummy, replace as needed
}

export function deleteFirst<T>(lst: List<T>, el: T): List<T> {
  return lst; // dummy, replace as needed
}

export function deleteLast<T>(lst: List<T>, el: T): List<T> {
  return lst; // dummy, replace as needed
}

export function squashList(lst: List<number | List<number>>): List<number> {
  return empty(); // dummy, replace as needed
}