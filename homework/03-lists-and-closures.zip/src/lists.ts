import { List, node, empty } from "../include/lists.js";

export function keepTrendMiddles(
  lst: List<number>, 
  allSatisfy: (prev: number, curr: number, next: number) => boolean
): List<number> {
  // TODO: Implement this function
  return lst;
}

export function keepLocalMaxima(lst: List<number>): List<number> {
  // TODO: Implement this function
  return lst;
}

export function keepLocalMinima(lst: List<number>): List<number> {
  // TODO: Implement this function
  return lst;
}

export function keepLocalMinimaAndMaxima(lst: List<number>): List<number> {
  // TODO: Implement this function
  return lst;
}

export function everyNList<T>(lst: List<T>, n: number): List<T> {
  // TODO: Implement this function
  return lst;
}

export function everyNRev<T>(lst: List<T>, n: number): List<T> {
  // TODO: Implement this function
  return lst;
}

export function everyNCond<T>(lst: List<T>, n: number, cond: (e: T) => boolean): List<T> {
  // TODO: Implement this function
  return lst;
}

export function nonNegativeProducts(lst: List<number>): List<number> {
  // TODO: Implement this function
  return lst;
}

export function negativeProducts(lst: List<number>): List<number> {
  // TODO: Implement this function
  return lst;
}

export function squashList(lst: List<number | List<number>>): List<number> {
  // TODO: Implement this function
  return node(1, node(2, empty()));
}

export function composeList<T>(lst: List<(n: T) => T>): (n: T) => T {
  // TODO: Implement this function
  return (n: T) => n;
}

export function composeFunctions<T>(fns: ((x: T) => T)[]): (x: T) => T[] {
  // TODO: Implement this function
  return (x: T) => [];
}