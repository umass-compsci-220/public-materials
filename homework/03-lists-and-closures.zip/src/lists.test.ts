import { List, node, empty, listToArray, arrayToList } from "../include/lists.js";
import {
  keepTrendMiddles,
  keepLocalMaxima,
  keepLocalMinima,
  keepLocalMinimaAndMaxima,
  everyNList,
  everyNRev,
  everyNCond,
  nonNegativeProducts,
  negativeProducts,
  squashList,
  composeList,
  composeFunctions,
  extraClosuresPractice
} from "./lists.js";

// listToArray and arrayToList are provided for your testing convinience only.

describe("keepTrendMiddles", () => {
  // Tests for keepTrendMiddles go here
});

describe("keepLocalMaxima", () => {
  // Tests for keepLocalMaxima go here
});

describe("keepLocalMinima", () => {
  // Tests for keepLocalMinima go here
});

describe("keepLocalMinimaAndMaxima", () => {
  // Tests for keepLocalMinimaAndMaxima go here
});

describe("everyNList", () => {
  // Tests for everyNList go here
});

describe("everyNRev", () => {
  // Tests for everyNRev go here
});

describe("everyNCond", () => {
  // Tests for everyNCond go here
});

describe("nonNegativeProducts", () => {
   // Tests for nonNegativeProducts go here
});

describe("negativeProducts", () => {
    // Tests for nonNegativeProducts go here
});

describe("squashList", () => {
  // Tests for squashList go here
});

describe("composeList", () => {
  // Tests for composeList go here
});

// Optional

describe("extraClosuresPractice", () => {
  // If you implemented extraClosuresPractice your tests for it should go here.
  // If you did not implement that function, delete this test skeleton and the respective import above.
});